document.getElementById('salir').addEventListener('click', function () {
    // Redirige a otra página
    window.location.href = '../Profesor/13-calificaciones.html';
});


