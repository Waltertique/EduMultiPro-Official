document.getElementById('intruccion').addEventListener('click', function () {
    // Redirige a otra página
    window.location.href = '../Profesor/11-verTrabajo.html';
});

document.getElementById('subidos').addEventListener('click', function () {
    // Redirige a otra página
    window.location.href = '../Profesor/12-subidos.html';
});

