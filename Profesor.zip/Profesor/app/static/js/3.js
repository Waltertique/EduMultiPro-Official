document.getElementById('inicio').addEventListener('click', function () {
    // Redirige a otra página
    window.location.href = '../Profesor/1-principalProfesor.html';
});

document.getElementById('noticia').addEventListener('click', function () {
    // Redirige a otra página
    window.location.href = '../Profesor/2-noticias.html';
});

document.getElementById('horario').addEventListener('click', function () {
    // Redirige a otra página
    window.location.href = '../Profesor/4-horario.html';
});

document.getElementById('clases').addEventListener('click', function () {
    // Redirige a otra página
    window.location.href = '../Profesor/5-aula.html';
});

document.getElementById('notas').addEventListener('click', function () {
    // Redirige a otra página
    window.location.href = '../Profesor/13-calificaciones.html';
});

document.getElementById('usuario').addEventListener('click', function () {
    // Redirige a otra página
    window.location.href = '../Profesor/Usuario.html';
});

document.getElementById('salir').addEventListener('click', function () {
    // Redirige a otra página
    window.location.href = '../Principal/index.html';
});