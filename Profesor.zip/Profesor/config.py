class Config:
    SECRET_KEY = 'CLAVE'
    MYSQL_HOST = 'localhost'
    MYSQL_USER = 'root'
    MYSQL_PASSWORD = '1234'
    MYSQL_DB = 'EduMultiPro'
    SESSION_COOKIE_SECURE = False